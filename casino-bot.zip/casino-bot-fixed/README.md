# Casino Bot

A Discord bot with a virtual-currency economy and 8 casino games: Gold Mines,
Mines, Chicken Fight, High-Low, Higher-Tail, Slots, Crash, and Blackjack.

Data is stored in plain JSON files under `data/` and is only ever added to —
restarting, redeploying, or updating the bot's code never resets balances.

## Folder structure

```
casino-bot/
├── package.json
├── .env.example
├── index.js              # entry point — loads economy/, games/, admin/ and routes $commands
├── embeds.js              # shared embed styling
├── permissions.js         # role / admin permission checks
├── utils.js               # bet parsing, formatting, RNG helpers
├── data/
│   ├── economy.js         # load/save player balances + getUser()
│   ├── economy.json        # persisted player data (auto-created, never wiped)
│   ├── config.js           # load/save server settings
│   └── config.json         # persisted casino-role + game-room settings
├── economy/                # bal, top, pay, work, crime, rob
├── games/                  # gm, mines, cf, hl, ht, slots, crash, bj
└── admin/                  # addmoney, removemoney, addmoney-role, casino-role, setgameroom
```

Every file's `require()` path matches exactly one level of nesting: files
inside `economy/`, `games/`, and `admin/` reach shared code with `../utils`,
`../embeds`, `../permissions`, and `../data/economy` (never `../../`, since
nothing is nested two levels deep). If you ever move a command file, keep
that in mind — a wrong relative path is exactly what silently broke the
previous layout (the folder just wasn't found, so it loaded zero commands
without crashing).

`index.js` now also **logs how many commands it loaded from each folder** on
startup, e.g.:
```
[commands] loaded 6 file(s) from economy/
[commands] loaded 8 file(s) from games/
[commands] loaded 5 file(s) from admin/
```
If any of those says `0`, or you see a `folder not found, skipping` warning,
that tells you immediately which folder is missing or misnamed — instead of
the bot silently starting with no commands like before.

## Setup

1. **Install Node.js 18+** if you don't have it.
2. In this folder, install dependencies:
   ```
   npm install
   ```
3. Create a Discord application + bot at https://discord.com/developers/applications,
   turn on the **Message Content Intent** and **Server Members Intent** under
   Bot settings, and copy the bot token.
4. Copy `.env.example` to `.env` and paste your token in:
   ```
   cp .env.example .env
   ```
5. Invite the bot to your server with the `bot` scope and these permissions:
   Send Messages, Embed Links, Read Message History, Use External Emojis.
6. Start the bot:
   ```
   npm start
   ```

## Migrating from an older copy

If you already had the bot running with real player balances saved
somewhere (an old `economy.json` / `data.json`), copy just the `"users": {...}`
object from the old file into the new `data/economy.json` before starting
this version, so balances aren't lost. If you're starting fresh, do nothing —
`data/economy.json` and `data/config.json` are created automatically on
first run.

## Commands

Default prefix is `$` (change it with `PREFIX` in `.env`).

Every bet amount accepts a number (e.g. `500`, `1,000`), `all`, or `half`.

### Games
| Command | Description |
|---|---|
| `$gm <amount>` | Gold Mines — 5×4 grid, 12 bombs, 8 safe tiles (2 coins ×2, 2 diamonds ×2.5, 3 rocks ×1.1, 1 rare jar ×27.5 / moneybag ×5). Cash out any time after your first safe dig. |
| `$mines <amount>` | Mines — 3×3 grid, 1 bomb. Multiplier climbs 1.1 → 1.4 → 1.7 → 2 → 2.7 → 4 → 6.5 → 8.7 as you clear diamonds. |
| `$cf <amount>` | Chicken Fight — win chance starts at 50%, +1% per consecutive win, capped at 85%. Pays 1:1. |
| `$hl <amount>` | Higher or Lower — rolls 1–10. Higher ×2.1, Lower ×1.9, Same ×15 (rare). |
| `$ht <amount>` | Higher/Tail coin flip. Pays 2× (profit = bet). |
| `$slots <amount>` | 3-reel slots with a short spin animation. Triples pay 2×–10× depending on symbol; any pair pays 1.2×. |
| `$crash <amount>` | Multiplier rises live; hit **Cash Out** before it crashes. |
| `$bj <amount>` | Blackjack — dealer stands on 17+, natural blackjack pays 3:2, regular win pays 1:1, push returns your bet, basic Split supported. |

### Economy
| Command | Description |
|---|---|
| `$bal` | Shows your cash (Money Out), Bank, and Total, with a button to view the leaderboard. |
| `$top` / `$lb` | Leaderboard with Bank / Total / Cash tabs and pagination. |
| `$work` | Guaranteed payout, short cooldown. |
| `$crime` | Guaranteed (higher) payout, short cooldown. |
| `$rob @user` | Steal 10–30% of a player's cash. **15% chance to get caught and get nothing.** |
| `$pay @user <amount|all|half>` | Send cash to another player. |

### Admin / setup
| Command | Who can use it | What it does |
|---|---|---|
| `$casino-role @role` | Server **Administrators** only | Sets which role counts as "Casino Staff" for the money commands below. |
| `$addmoney <bank\|cash> @user <amount>` | Casino Staff or Administrators | Grants money to a player. |
| `$removemoney <bank\|cash> @user <amount>` | Casino Staff or Administrators | Removes money from a player. |
| `$addmoney-role <bank\|cash> @role <amount>` | Casino Staff or Administrators | Grants money to every member holding a role. |
| `$setgameroom` (or `$setgameroom #channel ...`) | Server **Administrators** only | Toggles which channel(s) the games/economy commands work in. Run with no arguments in a channel to add/remove *that* channel. With no game room configured, commands work everywhere. |

There is no hardcoded "owner" user ID anywhere in the code — every admin
action is gated by real Discord permissions (the **Administrator** permission,
or the role you choose with `$casino-role`).

## What was intentionally left out

- **A "predict" command that reveals hidden game outcomes in advance** —
  regardless of who has access to it, that's a cheating tool against everyone
  else betting in the same economy, not a game feature.
- **Admin powers hardcoded to one personal Discord user ID** — instead,
  `$casino-role` and `$setgameroom` are gated by the real Discord
  **Administrator** permission.

## Customizing odds

Every multiplier/probability lives near the top of its game file as a plain
constant (e.g. `MULT` in `games/hl.js`, `MULTIPLIERS` in `games/mines.js`,
the tile table in `games/gm.js`), so you can tune the house edge without
touching any game logic.
