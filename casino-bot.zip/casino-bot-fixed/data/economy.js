const fs = require('fs');
const path = require('path');

const ECONOMY_PATH = path.join(__dirname, 'economy.json');
const STARTING_CASH = Number(process.env.STARTING_CASH || 15000);

// This file is only ever ADDED to / updated in place. Restarting or
// redeploying the bot never wipes it, so player balances persist across
// bot restarts/updates.
function ensureFile() {
  if (!fs.existsSync(ECONOMY_PATH)) {
    fs.writeFileSync(ECONOMY_PATH, JSON.stringify({ users: {} }, null, 2));
  }
}

function loadEconomy() {
  ensureFile();
  return JSON.parse(fs.readFileSync(ECONOMY_PATH, 'utf8'));
}

function saveEconomy(data) {
  fs.writeFileSync(ECONOMY_PATH, JSON.stringify(data, null, 2));
}

function getUser(data, userId) {
  if (!data.users[userId]) {
    data.users[userId] = {
      cash: STARTING_CASH,
      bank: 0,
      cfStreak: 0, // chicken-fight current win streak
      moneyOut: STARTING_CASH // lifetime "money out" stat, shown by $bal
    };
  }
  // backfill fields for older saves
  const u = data.users[userId];
  if (u.cfStreak === undefined) u.cfStreak = 0;
  if (u.bank === undefined) u.bank = 0;
  if (u.moneyOut === undefined) u.moneyOut = u.cash + u.bank;
  return u;
}

module.exports = { loadEconomy, saveEconomy, getUser, STARTING_CASH };
