const fs = require('fs');
const path = require('path');

const CONFIG_PATH = path.join(__dirname, 'config.json');

function ensureFile() {
  if (!fs.existsSync(CONFIG_PATH)) {
    fs.writeFileSync(CONFIG_PATH, JSON.stringify({ casinoRoleId: null, gameRooms: [] }, null, 2));
  }
}

function loadConfig() {
  ensureFile();
  const cfg = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
  if (!cfg.gameRooms) cfg.gameRooms = [];
  if (cfg.casinoRoleId === undefined) cfg.casinoRoleId = null;
  return cfg;
}

function saveConfig(cfg) {
  fs.writeFileSync(CONFIG_PATH, JSON.stringify(cfg, null, 2));
}

module.exports = { loadConfig, saveConfig };
